const functions = require('@google-cloud/functions-framework');
 
functions.cloudEvent('fileStorageAlert', (cloudevent) => {
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("cloud storage event");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log(cloudevent);
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");
  console.log("===================");

});